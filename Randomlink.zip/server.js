const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// Database connection
const db = new sqlite3.Database('./database.db', (err) => {
    if (err) {
        console.error('Error connecting to database:', err.message);
    } else {
        console.log('Connected to SQLite database');
        initDatabase();
    }
});

// Initialize database tables
function initDatabase() {
    db.serialize(() => {
        // Create catalogues table
        db.run(`CREATE TABLE IF NOT EXISTS catalogues (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            description TEXT NOT NULL,
            color TEXT NOT NULL DEFAULT '#667eea',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )`);

        // Create links table
        db.run(`CREATE TABLE IF NOT EXISTS links (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            catalogue_id INTEGER NOT NULL,
            url TEXT NOT NULL UNIQUE,
            description TEXT NOT NULL,
            clicks INTEGER DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (catalogue_id) REFERENCES catalogues (id) ON DELETE CASCADE
        )`);

        // Insert default catalogues if none exist
        db.get("SELECT COUNT(*) as count FROM catalogues", (err, row) => {
            if (err) {
                console.error('Error checking catalogues:', err.message);
                return;
            }

            if (row.count === 0) {
                console.log('Inserting default catalogues...');
                const defaultCatalogues = [
                    { name: 'Công cụ', description: 'Các công cụ hữu ích', color: '#667eea' },
                    { name: 'Giải trí', description: 'Nội dung giải trí', color: '#e74c3c' },
                    { name: 'Học tập', description: 'Tài liệu học tập', color: '#27ae60' }
                ];

                const stmt = db.prepare("INSERT INTO catalogues (name, description, color) VALUES (?, ?, ?)");
                defaultCatalogues.forEach(cat => {
                    stmt.run([cat.name, cat.description, cat.color]);
                });
                stmt.finalize();

                // Insert default links
                setTimeout(() => {
                    const defaultLinks = [
                        { catalogue_id: 1, url: 'https://google.com', description: 'Tìm kiếm Google' },
                        { catalogue_id: 2, url: 'https://youtube.com', description: 'Xem video YouTube' },
                        { catalogue_id: 1, url: 'https://github.com', description: 'Repository GitHub' }
                    ];

                    const linkStmt = db.prepare("INSERT INTO links (catalogue_id, url, description) VALUES (?, ?, ?)");
                    defaultLinks.forEach(link => {
                        linkStmt.run([link.catalogue_id, link.url, link.description]);
                    });
                    linkStmt.finalize();
                    console.log('Default data inserted successfully');
                }, 100);
            }
        });
    });
}

// API Routes

// Get all catalogues
app.get('/api/catalogues', (req, res) => {
    db.all("SELECT * FROM catalogues ORDER BY created_at ASC", (err, rows) => {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json(rows);
    });
});

// Create new catalogue
app.post('/api/catalogues', (req, res) => {
    const { name, description, color } = req.body;

    if (!name || !description) {
        res.status(400).json({ error: 'Name and description are required' });
        return;
    }

    const stmt = db.prepare("INSERT INTO catalogues (name, description, color) VALUES (?, ?, ?)");
    stmt.run([name, description, color || '#667eea'], function(err) {
        if (err) {
            if (err.message.includes('UNIQUE constraint failed')) {
                res.status(400).json({ error: 'Catalogue name already exists' });
            } else {
                res.status(500).json({ error: err.message });
            }
            return;
        }
        res.json({ id: this.lastID, name, description, color: color || '#667eea' });
    });
    stmt.finalize();
});

// Delete catalogue
app.delete('/api/catalogues/:id', (req, res) => {
    const id = req.params.id;

    // First delete associated links
    db.run("DELETE FROM links WHERE catalogue_id = ?", [id], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }

        // Then delete the catalogue
        db.run("DELETE FROM catalogues WHERE id = ?", [id], function(err) {
            if (err) {
                res.status(500).json({ error: err.message });
                return;
            }

            if (this.changes === 0) {
                res.status(404).json({ error: 'Catalogue not found' });
                return;
            }

            res.json({ message: 'Catalogue deleted successfully' });
        });
    });
});

// Get all links with catalogue information
app.get('/api/links', (req, res) => {
    const catalogueId = req.query.catalogue_id;

    let query = `
        SELECT l.*, c.name as catalogue_name, c.color as catalogue_color
        FROM links l
        JOIN catalogues c ON l.catalogue_id = c.id
    `;
    let params = [];

    if (catalogueId && catalogueId !== 'all') {
        query += ' WHERE l.catalogue_id = ?';
        params = [catalogueId];
    }

    query += ' ORDER BY l.created_at ASC';

    db.all(query, params, (err, rows) => {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json(rows);
    });
});

// Create new link
app.post('/api/links', (req, res) => {
    const { catalogue_id, url, description } = req.body;

    if (!catalogue_id || !url || !description) {
        res.status(400).json({ error: 'Catalogue ID, URL, and description are required' });
        return;
    }

    const stmt = db.prepare("INSERT INTO links (catalogue_id, url, description) VALUES (?, ?, ?)");
    stmt.run([catalogue_id, url, description], function(err) {
        if (err) {
            if (err.message.includes('UNIQUE constraint failed')) {
                res.status(400).json({ error: 'URL already exists' });
            } else {
                res.status(500).json({ error: err.message });
            }
            return;
        }
        res.json({ id: this.lastID, catalogue_id, url, description, clicks: 0 });
    });
    stmt.finalize();
});

// Update link clicks
app.patch('/api/links/:id/click', (req, res) => {
    const id = req.params.id;

    db.run("UPDATE links SET clicks = clicks + 1 WHERE id = ?", [id], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }

        if (this.changes === 0) {
            res.status(404).json({ error: 'Link not found' });
            return;
        }

        // Return updated link
        db.get("SELECT * FROM links WHERE id = ?", [id], (err, row) => {
            if (err) {
                res.status(500).json({ error: err.message });
                return;
            }
            res.json(row);
        });
    });
});

// Delete link
app.delete('/api/links/:id', (req, res) => {
    const id = req.params.id;

    db.run("DELETE FROM links WHERE id = ?", [id], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }

        if (this.changes === 0) {
            res.status(404).json({ error: 'Link not found' });
            return;
        }

        res.json({ message: 'Link deleted successfully' });
    });
});

// Get statistics
app.get('/api/stats', (req, res) => {
    db.serialize(() => {
        const stats = {};

        db.get("SELECT COUNT(*) as count FROM catalogues", (err, row) => {
            if (err) {
                res.status(500).json({ error: err.message });
                return;
            }
            stats.totalCatalogues = row.count;

            db.get("SELECT COUNT(*) as count FROM links", (err, row) => {
                if (err) {
                    res.status(500).json({ error: err.message });
                    return;
                }
                stats.totalLinks = row.count;

                db.get("SELECT SUM(clicks) as total FROM links", (err, row) => {
                    if (err) {
                        res.status(500).json({ error: err.message });
                        return;
                    }
                    stats.totalClicks = row.total || 0;

                    db.get("SELECT description, clicks FROM links ORDER BY clicks DESC LIMIT 1", (err, row) => {
                        if (err) {
                            res.status(500).json({ error: err.message });
                            return;
                        }
                        stats.mostClickedLink = row || { description: 'Chưa có', clicks: 0 };

                        res.json(stats);
                    });
                });
            });
        });
    });
});

// Export data
app.get('/api/export', (req, res) => {
    db.serialize(() => {
        db.all("SELECT * FROM catalogues", (err, catalogues) => {
            if (err) {
                res.status(500).json({ error: err.message });
                return;
            }

            db.all("SELECT * FROM links", (err, links) => {
                if (err) {
                    res.status(500).json({ error: err.message });
                    return;
                }

                res.json({ catalogues, links });
            });
        });
    });
});

// Import data
app.post('/api/import', (req, res) => {
    const { catalogues, links } = req.body;

    if (!Array.isArray(catalogues) || !Array.isArray(links)) {
        res.status(400).json({ error: 'Invalid data format' });
        return;
    }

    db.serialize(() => {
        db.run("DELETE FROM links");
        db.run("DELETE FROM catalogues");

        // Insert catalogues
        const catStmt = db.prepare("INSERT INTO catalogues (name, description, color) VALUES (?, ?, ?)");
        catalogues.forEach(cat => {
            catStmt.run([cat.name, cat.description, cat.color]);
        });
        catStmt.finalize();

        // Insert links
        const linkStmt = db.prepare("INSERT INTO links (catalogue_id, url, description, clicks) VALUES (?, ?, ?, ?)");
        links.forEach(link => {
            linkStmt.run([link.catalogueId || link.catalogue_id, link.url, link.description, link.clicks || 0]);
        });
        linkStmt.finalize();

        res.json({ message: 'Data imported successfully' });
    });
});

// Clear all data
app.delete('/api/clear', (req, res) => {
    db.serialize(() => {
        db.run("DELETE FROM links", (err) => {
            if (err) {
                res.status(500).json({ error: err.message });
                return;
            }

            db.run("DELETE FROM catalogues", (err) => {
                if (err) {
                    res.status(500).json({ error: err.message });
                    return;
                }

                res.json({ message: 'All data cleared successfully' });
            });
        });
    });
});

// Serve the main application
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start server
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});

// Graceful shutdown
process.on('SIGINT', () => {
    console.log('\nShutting down gracefully...');
    db.close((err) => {
        if (err) {
            console.error('Error closing database:', err.message);
        } else {
            console.log('Database connection closed');
        }
        process.exit(0);
    });
});